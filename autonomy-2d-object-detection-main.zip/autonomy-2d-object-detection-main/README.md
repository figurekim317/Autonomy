# 2D Object Detection

Autonomy Object Detection Repository for ROS2 eloquent environment.

##### Dependency List

- Ubuntu 18.04
- ROS2 Eloquent
- NVIDIA GPU & DeepStream
